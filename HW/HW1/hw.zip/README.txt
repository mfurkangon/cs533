Please download the cc.en.300.bin model from the official website of FastText, 
locate it to the same directory as hw.ipynb.

Then, you can run the hw.ipynb cells to reproduce the models and plots. 
To reproduce the models, please uncomment the cells that are indicated.

If your system doesn't have the required libraries, please run the 
pip install -r "requirements.txt" first, then run
the Jupyter Notebook named hw.ipynb.

results.txt contains the results of the experiments. Before running any cell, 
you can have a look at the results also plots from the hw.ipynb.